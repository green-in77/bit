package kr.or.bit.action;

public class ActionForward {
	private String path = null; //이동경로 설정

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}
	
	
}
